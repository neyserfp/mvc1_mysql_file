<div id="contenedor0" class="contenedor0">
    <div id="contenedor1" class="contenedor1">
        <form id="formSubidaArchivos1" class="bloque1">
            <input type="text" id="textoInsercion1" name="textoInsercion1" required class="campo1" placeholder="Marca">
            <input type="text" id="textoInsercion2" name="textoInsercion2" required class="campo1" placeholder="Modelo">
            <input type="number" id="textoInsercion3" name="textoInsercion3" required class="campo1" placeholder="Autonomía">
            <input type="file" id="ficheroInsercion1" name="ficheroInsercion1" accept=".jpg, .jpeg, .png" required class="campoArchivo1">
            <input type="submit" id="botonInsercion1" name="botonInsercion1" value="Insertar" class="boton1">
        </form>
    </div>
    <div id="contenedor2" class="contenedor2">
    </div>
</div>
<footer class="pie1">
    <a href="#">Contacto</a>
    <a href="#">Privacidad</a>
    <a href="#">MVC - PHP y MySQL</a>
</footer>
<div class="menu1">
    <a href="index.php">Inicio</a>
    <a href="consulta.php">Consulta</a>
    <a href="insercion.php">Insercion</a>
    <a href="insercion-y-consulta.php">Inserción y Consulta (Inserción Múltiple)</a>
    <a href="insercion-con-declaraciones-preparadas.php">Inserción con Declaraciones Preparadas</a>
    <a href="insercionConSubidaDeArchivos.php">Inserción con Subida de Archivos</a>
</div>